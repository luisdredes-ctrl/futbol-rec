# Fútbol Rec — grabación de partidos amateur

App para Android e iOS que **graba el partido en video** y, al mismo tiempo, permite
**marcar eventos** (gol, tiro, falta, tarjetas, cambio, momento destacado) con
botones grandes. Después, en la línea de tiempo del partido, tocas un evento y el
video salta directo a esa jugada (10 segundos antes, para ver cómo se armó).

Todo funciona **sin internet** y se guarda en el teléfono. La fase 2 (servidor
central para compartir los videos) se construye sobre esta misma base.

---

## 1. Instalar las herramientas (solo la primera vez)

Necesitas un computador. Para compilar la versión iOS **obligatoriamente** debe ser
un Mac; para Android sirve Windows, Mac o Linux.

1. **Flutter**: sigue la guía oficial para tu sistema:
   https://docs.flutter.dev/install (descarga manual del SDK: https://docs.flutter.dev/install/manual · configurar Android: https://docs.flutter.dev/platform-integration/android/setup)
   Elige "Android" como primera plataforma. La guía te lleva también a instalar
   **Android Studio**. Al terminar, abre una terminal y escribe:
   ```
   flutter doctor
   ```
   Debe mostrar ✓ en Flutter y en Android toolchain. Si falta algo, el mismo
   comando dice qué hacer.

2. **Un teléfono Android** con "Depuración USB" activada (Ajustes → Acerca del
   teléfono → toca 7 veces "Número de compilación" → vuelve → Opciones de
   desarrollador → Depuración USB). Conéctalo por cable.

   > Puedes usar el emulador de Android Studio para ver las pantallas, pero la
   > cámara del emulador es falsa; para probar de verdad necesitas un teléfono.

3. *(Solo iOS)* En el Mac instala **Xcode** desde la App Store y ejecuta
   `flutter doctor` otra vez.

---

## 2. Crear el proyecto con este código

Este paquete trae el código de la app (`lib/`) y la lista de dependencias
(`pubspec.yaml`). Flutter genera el resto (carpetas `android/` e `ios/`) con un
comando:

```
flutter create --org com.tunombre --project-name futbol_rec futbol_rec_app
```

Luego:

1. Borra la carpeta `futbol_rec_app/lib` que creó Flutter y **copia** en su lugar
   la carpeta `lib` de este paquete.
2. Reemplaza `futbol_rec_app/pubspec.yaml` por el `pubspec.yaml` de este paquete.
3. Abre `futbol_rec_app/android/app/src/main/AndroidManifest.xml` y pega las
   líneas de `platform_extras/AndroidManifest_permisos.xml` donde se indica.
4. Abre `futbol_rec_app/android/app/build.gradle` (o `build.gradle.kts`) y
   asegúrate de que `minSdk` sea **21 o mayor** (busca `minSdk`).
5. *(Solo iOS)* Abre `futbol_rec_app/ios/Runner/Info.plist` y pega las líneas de
   `platform_extras/Info_plist_permisos.xml`.

Descarga las dependencias:

```
cd futbol_rec_app
flutter pub get
```

---

## 3. Ejecutar en el teléfono

Con el teléfono conectado por USB:

```
flutter run
```

La primera vez tarda varios minutos. Después la app queda instalada en el
teléfono y puedes abrirla sin el computador.

Para generar el instalador de Android (archivo `.apk`) y pasarlo a otros
teléfonos:

```
flutter build apk --release
```

El archivo queda en `build/app/outputs/flutter-apk/app-release.apk`.

---

## 4. Cómo se usa la app

1. **Nuevo partido**: nombres de los equipos, duración de cada tiempo (30 min por
   defecto) y, si quieres, los jugadores (uno por línea, con número al inicio).
2. Se abre la **pantalla de grabación** en horizontal. Pon el teléfono en un
   trípode apuntando a la cancha.
3. **Iniciar 1er tiempo**: empieza el video y el cronómetro.
4. Selecciona el equipo (chips de la izquierda) y toca el evento (botones de la
   derecha). Si cargaste jugadores, te pregunta quién fue.
5. **Fin 1er tiempo** guarda el video del primer tiempo. En el entretiempo no se
   graba nada (no gasta espacio ni batería).
6. **Iniciar 2do tiempo** → **Fin del partido**.
7. En la lista de partidos, toca uno para ver el video y la línea de tiempo.
   Toca cualquier evento para saltar a la jugada.

Espacio aproximado: **~2 GB por partido de 60 min** en 720p (calidad por
defecto). Si quieres 1080p, en `lib/screens/recording_screen.dart` cambia
`ResolutionPreset.high` por `ResolutionPreset.veryHigh` (~4 GB por partido).

---

## 5. Estructura del código

```
lib/
├── main.dart                      Arranque de la app
├── models/models.dart             Partido, Equipo, Jugador, Evento (y su JSON)
├── services/storage_service.dart  Guardado local (JSON + videos)
├── screens/
│   ├── home_screen.dart           Lista de partidos
│   ├── new_match_screen.dart      Formulario de nuevo partido
│   ├── recording_screen.dart      ★ Cámara + cronómetro + botones de eventos
│   └── match_detail_screen.dart   Video + línea de tiempo
└── widgets/event_button.dart      Botón grande de evento
```

---

## 6. Próximos pasos (hoja de ruta)

**Fase 1 (local, en el teléfono)**
- [x] Grabar por tiempos, marcar eventos, saltar a la jugada
- [ ] Generar clips automáticos por evento y un "resumen" del partido
- [ ] Estadísticas por jugador acumuladas entre partidos
- [ ] Compartir un clip por WhatsApp

**Fase 2 (servidor central)**
- [ ] Cuenta de usuario / equipo
- [ ] Subida del video y los eventos en segundo plano cuando haya wifi
- [ ] Web para ver partidos y clips desde cualquier dispositivo

Cada partido ya tiene un `id` único y un campo `uploaded`, pensados para la
sincronización de la fase 2.

---

## Problemas frecuentes

- **"No se pudo abrir la cámara"**: revisa que pegaste los permisos del paso 2 y
  que aceptaste el permiso de cámara/micrófono en el teléfono.
- **La pantalla no gira a horizontal**: es normal en el emulador; en un teléfono
  real sí gira.
- **`flutter doctor` marca error en Android licenses**: ejecuta
  `flutter doctor --android-licenses` y acepta con `y`.
