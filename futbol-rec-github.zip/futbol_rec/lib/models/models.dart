import 'package:uuid/uuid.dart';

const _uuid = Uuid();

/// Tipos de evento que se pueden marcar durante el partido.
enum EventType {
  goal('Gol', '⚽'),
  shot('Tiro', '🎯'),
  foul('Falta', '🚫'),
  yellowCard('Amarilla', '🟨'),
  redCard('Roja', '🟥'),
  substitution('Cambio', '🔄'),
  highlight('Destacado', '⭐');

  const EventType(this.label, this.emoji);
  final String label;
  final String emoji;
}

class Player {
  Player({String? id, required this.name, this.number})
      : id = id ?? _uuid.v4();

  final String id;
  String name;
  int? number;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'number': number};

  factory Player.fromJson(Map<String, dynamic> j) =>
      Player(id: j['id'], name: j['name'], number: j['number']);
}

class Team {
  Team({String? id, required this.name, List<Player>? players})
      : id = id ?? _uuid.v4(),
        players = players ?? [];

  final String id;
  String name;
  final List<Player> players;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'players': players.map((p) => p.toJson()).toList(),
      };

  factory Team.fromJson(Map<String, dynamic> j) => Team(
        id: j['id'],
        name: j['name'],
        players: (j['players'] as List? ?? [])
            .map((p) => Player.fromJson(p))
            .toList(),
      );
}

/// Un evento marcado durante la grabación.
///
/// [period] es 1 o 2. [matchSeconds] son los segundos transcurridos del
/// cronómetro del partido en ese tiempo. [videoOffsetMs] es la posición exacta
/// dentro del video de ese tiempo, para poder saltar al momento justo.
class MatchEvent {
  MatchEvent({
    String? id,
    required this.type,
    required this.period,
    required this.matchSeconds,
    required this.videoOffsetMs,
    required this.teamId,
    this.playerId,
    this.note,
  }) : id = id ?? _uuid.v4();

  final String id;
  final EventType type;
  final int period;
  final int matchSeconds;
  final int videoOffsetMs;
  final String teamId;
  String? playerId;
  String? note;

  /// Minuto del partido en formato "23'" (el segundo tiempo continúa la cuenta).
  String minuteLabel(int periodMinutes) {
    final base = (period - 1) * periodMinutes;
    final min = base + matchSeconds ~/ 60;
    return "$min'";
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'period': period,
        'matchSeconds': matchSeconds,
        'videoOffsetMs': videoOffsetMs,
        'teamId': teamId,
        'playerId': playerId,
        'note': note,
      };

  factory MatchEvent.fromJson(Map<String, dynamic> j) => MatchEvent(
        id: j['id'],
        type: EventType.values.byName(j['type']),
        period: j['period'],
        matchSeconds: j['matchSeconds'],
        videoOffsetMs: j['videoOffsetMs'],
        teamId: j['teamId'],
        playerId: j['playerId'],
        note: j['note'],
      );
}

class FootballMatch {
  FootballMatch({
    String? id,
    required this.date,
    required this.homeTeam,
    required this.awayTeam,
    this.periodMinutes = 30,
    List<MatchEvent>? events,
    Map<int, String>? videoPaths,
    this.uploaded = false,
  })  : id = id ?? _uuid.v4(),
        events = events ?? [],
        videoPaths = videoPaths ?? {};

  final String id;
  final DateTime date;
  final Team homeTeam;
  final Team awayTeam;
  int periodMinutes;
  final List<MatchEvent> events;

  /// Ruta del archivo de video por tiempo: {1: '.../t1.mp4', 2: '.../t2.mp4'}
  final Map<int, String> videoPaths;

  /// Reservado para la fase 2 (sincronización con el servidor central).
  bool uploaded;

  int goalsFor(Team t) =>
      events.where((e) => e.type == EventType.goal && e.teamId == t.id).length;

  Team teamById(String id) => id == homeTeam.id ? homeTeam : awayTeam;

  Player? playerById(String? id) {
    if (id == null) return null;
    for (final p in [...homeTeam.players, ...awayTeam.players]) {
      if (p.id == id) return p;
    }
    return null;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'homeTeam': homeTeam.toJson(),
        'awayTeam': awayTeam.toJson(),
        'periodMinutes': periodMinutes,
        'events': events.map((e) => e.toJson()).toList(),
        'videoPaths': videoPaths.map((k, v) => MapEntry(k.toString(), v)),
        'uploaded': uploaded,
      };

  factory FootballMatch.fromJson(Map<String, dynamic> j) => FootballMatch(
        id: j['id'],
        date: DateTime.parse(j['date']),
        homeTeam: Team.fromJson(j['homeTeam']),
        awayTeam: Team.fromJson(j['awayTeam']),
        periodMinutes: j['periodMinutes'] ?? 30,
        events: (j['events'] as List? ?? [])
            .map((e) => MatchEvent.fromJson(e))
            .toList(),
        videoPaths: (j['videoPaths'] as Map? ?? {})
            .map((k, v) => MapEntry(int.parse(k), v as String)),
        uploaded: j['uploaded'] ?? false,
      );
}
