import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/models.dart';

/// Guarda los partidos en un archivo JSON local y los videos en la carpeta
/// de documentos de la app. Todo funciona sin internet.
///
/// En la fase 2 este servicio será el punto de partida para sincronizar con el
/// servidor central: cada partido tiene un `id` único y un flag `uploaded`.
class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  List<FootballMatch> _matches = [];
  List<FootballMatch> get matches => List.unmodifiable(_matches);

  Future<Directory> get _docsDir => getApplicationDocumentsDirectory();

  Future<File> get _dbFile async =>
      File(p.join((await _docsDir).path, 'matches.json'));

  Future<Directory> get videosDir async {
    final dir = Directory(p.join((await _docsDir).path, 'videos'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> load() async {
    final f = await _dbFile;
    if (!await f.exists()) {
      _matches = [];
      return;
    }
    final list = jsonDecode(await f.readAsString()) as List;
    _matches = list.map((j) => FootballMatch.fromJson(j)).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  Future<void> save() async {
    final f = await _dbFile;
    await f.writeAsString(jsonEncode(_matches.map((m) => m.toJson()).toList()));
  }

  Future<void> addMatch(FootballMatch m) async {
    _matches.insert(0, m);
    await save();
  }

  Future<void> deleteMatch(FootballMatch m) async {
    for (final path in m.videoPaths.values) {
      final f = File(path);
      if (await f.exists()) await f.delete();
    }
    _matches.removeWhere((x) => x.id == m.id);
    await save();
  }

  /// Mueve el video grabado (que la cámara deja en una carpeta temporal) a la
  /// carpeta permanente de la app y devuelve la nueva ruta.
  Future<String> storeVideo(String tempPath, FootballMatch m, int period) async {
    final dir = await videosDir;
    final dest = p.join(dir.path, '${m.id}_t$period.mp4');
    try {
      final moved = await File(tempPath).rename(dest);
      return moved.path;
    } on FileSystemException {
      // rename falla si es otra partición: copiamos y borramos.
      final copy = await File(tempPath).copy(dest);
      await File(tempPath).delete();
      return copy.path;
    }
  }

  /// Espacio libre aproximado en el dispositivo (MB). Devuelve null si no se
  /// puede calcular.
  Future<int?> freeSpaceMb() async {
    try {
      final dir = await _docsDir;
      final result = await Process.run('df', ['-k', dir.path]);
      final lines = (result.stdout as String).trim().split('\n');
      if (lines.length < 2) return null;
      final cols = lines.last.split(RegExp(r'\s+'));
      return int.parse(cols[3]) ~/ 1024;
    } catch (_) {
      return null;
    }
  }
}
