import 'package:flutter/material.dart';

import '../models/models.dart';

/// Botón grande y fácil de tocar (pensado para usar a distancia, con el
/// teléfono en un trípode).
class EventButton extends StatelessWidget {
  const EventButton({
    super.key,
    required this.type,
    required this.onPressed,
    this.enabled = true,
  });

  final EventType type;
  final VoidCallback onPressed;
  final bool enabled;

  Color get _color => switch (type) {
        EventType.goal => Colors.green,
        EventType.shot => Colors.blue,
        EventType.foul => Colors.deepOrange,
        EventType.yellowCard => Colors.amber,
        EventType.redCard => Colors.red,
        EventType.substitution => Colors.purple,
        EventType.highlight => Colors.teal,
      };

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 130,
      height: 44,
      child: FilledButton(
        style: FilledButton.styleFrom(
          backgroundColor: _color,
          foregroundColor: Colors.white,
          padding: EdgeInsets.zero,
        ),
        onPressed: enabled ? onPressed : null,
        child: Text('${type.emoji} ${type.label}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
