import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/models.dart';
import '../services/storage_service.dart';
import 'match_detail_screen.dart';
import 'new_match_screen.dart';
import 'recording_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _storage = StorageService.instance;
  final _dateFmt = DateFormat("EEE d 'de' MMM, HH:mm", 'es');

  Future<void> _newMatch() async {
    final match = await Navigator.push<FootballMatch>(
      context,
      MaterialPageRoute(builder: (_) => const NewMatchScreen()),
    );
    if (match == null || !mounted) return;
    await _storage.addMatch(match);
    setState(() {});
    // Vamos directo a grabar.
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => RecordingScreen(match: match)),
    );
    setState(() {});
  }

  Future<void> _delete(FootballMatch m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('¿Eliminar partido?'),
        content: const Text('Se borrarán también los videos grabados.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok == true) {
      await _storage.deleteMatch(m);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final matches = _storage.matches;
    return Scaffold(
      appBar: AppBar(title: const Text('Fútbol Rec')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _newMatch,
        icon: const Icon(Icons.videocam),
        label: const Text('Nuevo partido'),
      ),
      body: matches.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Aún no hay partidos.\nToca "Nuevo partido" para empezar a grabar.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18),
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.only(bottom: 90),
              itemCount: matches.length,
              itemBuilder: (_, i) {
                final m = matches[i];
                final hasVideo = m.videoPaths.isNotEmpty;
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    leading: Icon(
                      hasVideo ? Icons.play_circle : Icons.videocam_off,
                      size: 36,
                    ),
                    title: Text(
                      '${m.homeTeam.name} ${m.goalsFor(m.homeTeam)} - '
                      '${m.goalsFor(m.awayTeam)} ${m.awayTeam.name}',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                        '${_dateFmt.format(m.date)} · ${m.events.length} eventos'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _delete(m),
                    ),
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => MatchDetailScreen(match: m)),
                      );
                      setState(() {});
                    },
                  ),
                );
              },
            ),
    );
  }
}
