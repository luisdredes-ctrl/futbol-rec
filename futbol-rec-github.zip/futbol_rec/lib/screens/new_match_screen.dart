import 'package:flutter/material.dart';

import '../models/models.dart';

/// Formulario para crear un partido: nombres de equipos, duración de cada
/// tiempo y (opcional) lista de jugadores por equipo.
class NewMatchScreen extends StatefulWidget {
  const NewMatchScreen({super.key});

  @override
  State<NewMatchScreen> createState() => _NewMatchScreenState();
}

class _NewMatchScreenState extends State<NewMatchScreen> {
  final _formKey = GlobalKey<FormState>();
  final _homeCtrl = TextEditingController(text: 'Local');
  final _awayCtrl = TextEditingController(text: 'Visita');
  final _homePlayersCtrl = TextEditingController();
  final _awayPlayersCtrl = TextEditingController();
  int _periodMinutes = 30;

  @override
  void dispose() {
    _homeCtrl.dispose();
    _awayCtrl.dispose();
    _homePlayersCtrl.dispose();
    _awayPlayersCtrl.dispose();
    super.dispose();
  }

  /// Convierte texto tipo "10 Pérez\n7 Soto\nGonzález" en jugadores.
  List<Player> _parsePlayers(String text) {
    final players = <Player>[];
    for (final raw in text.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      final m = RegExp(r'^(\d+)\s+(.+)$').firstMatch(line);
      if (m != null) {
        players.add(Player(name: m.group(2)!, number: int.parse(m.group(1)!)));
      } else {
        players.add(Player(name: line));
      }
    }
    return players;
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final match = FootballMatch(
      date: DateTime.now(),
      homeTeam: Team(
          name: _homeCtrl.text.trim(),
          players: _parsePlayers(_homePlayersCtrl.text)),
      awayTeam: Team(
          name: _awayCtrl.text.trim(),
          players: _parsePlayers(_awayPlayersCtrl.text)),
      periodMinutes: _periodMinutes,
    );
    Navigator.pop(context, match);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nuevo partido')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _homeCtrl,
              decoration: const InputDecoration(labelText: 'Equipo local'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Escribe un nombre' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _awayCtrl,
              decoration: const InputDecoration(labelText: 'Equipo visita'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Escribe un nombre' : null,
            ),
            const SizedBox(height: 20),
            Text('Duración de cada tiempo: $_periodMinutes min',
                style: Theme.of(context).textTheme.titleMedium),
            Slider(
              value: _periodMinutes.toDouble(),
              min: 10,
              max: 45,
              divisions: 7,
              label: '$_periodMinutes min',
              onChanged: (v) => setState(() => _periodMinutes = v.round()),
            ),
            const SizedBox(height: 12),
            const Text(
              'Jugadores (opcional). Uno por línea, con número al inicio si quieres:\n'
              '10 Pérez\n7 Soto',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _homePlayersCtrl,
              maxLines: 5,
              decoration: InputDecoration(
                  labelText: 'Jugadores ${_homeCtrl.text}',
                  border: const OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _awayPlayersCtrl,
              maxLines: 5,
              decoration: InputDecoration(
                  labelText: 'Jugadores ${_awayCtrl.text}',
                  border: const OutlineInputBorder()),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _submit,
              icon: const Icon(Icons.videocam),
              label: const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Crear y grabar', style: TextStyle(fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
