import 'dart:async';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../models/models.dart';
import '../services/storage_service.dart';
import '../widgets/event_button.dart';

/// Pantalla de grabación (horizontal).
///
/// Flujo:
///   1. "Iniciar 1er tiempo": arranca cámara + cronómetro.
///   2. Durante el tiempo se marcan eventos con los botones grandes.
///   3. "Fin 1er tiempo": detiene grabación y guarda el video del 1er tiempo.
///   4. "Iniciar 2do tiempo": nuevo video + cronómetro desde 0.
///   5. "Fin del partido": guarda y vuelve.
///
/// Cada tiempo es un archivo de video independiente. Así el entretiempo no
/// consume espacio y evitamos problemas si el teléfono se bloquea entre tiempos.
class RecordingScreen extends StatefulWidget {
  const RecordingScreen({super.key, required this.match});
  final FootballMatch match;

  @override
  State<RecordingScreen> createState() => _RecordingScreenState();
}

class _RecordingScreenState extends State<RecordingScreen>
    with WidgetsBindingObserver {
  CameraController? _cam;
  String? _camError;

  int _period = 1; // 1 o 2
  bool _recording = false;
  bool _finished = false;
  DateTime? _recStart;
  Timer? _ticker;
  int _elapsed = 0; // segundos del tiempo actual

  /// Equipo seleccionado para el próximo evento.
  late Team _selectedTeam = widget.match.homeTeam;

  int? _freeMb;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    WakelockPlus.enable();
    _initCamera();
    StorageService.instance.freeSpaceMb().then((mb) {
      if (mounted) setState(() => _freeMb = mb);
    });
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      final back = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      final cam = CameraController(
        back,
        ResolutionPreset.high, // 720p: ~2 GB por hora. Cambia a veryHigh para 1080p.
        enableAudio: true,
      );
      await cam.initialize();
      await cam.lockCaptureOrientation(DeviceOrientation.landscapeLeft);
      if (!mounted) return;
      setState(() => _cam = cam);
    } catch (e) {
      setState(() => _camError = 'No se pudo abrir la cámara: $e');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Si la app se va a segundo plano mientras graba, cerramos el tiempo
    // actual para no perder el video.
    if (state == AppLifecycleState.paused && _recording) {
      _stopPeriod();
    }
  }

  // ---------- Cronómetro y grabación ----------

  Future<void> _startPeriod() async {
    final cam = _cam;
    if (cam == null || _recording) return;
    await cam.startVideoRecording();
    _recStart = DateTime.now();
    _elapsed = 0;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _elapsed++);
    });
    setState(() => _recording = true);
  }

  Future<void> _stopPeriod() async {
    final cam = _cam;
    if (cam == null || !_recording) return;
    _ticker?.cancel();
    setState(() => _recording = false);
    final file = await cam.stopVideoRecording();
    final path = await StorageService.instance
        .storeVideo(file.path, widget.match, _period);
    widget.match.videoPaths[_period] = path;
    await StorageService.instance.save();
    if (!mounted) return;
    if (_period == 1) {
      setState(() => _period = 2);
    } else {
      setState(() => _finished = true);
    }
  }

  void _addEvent(EventType type) async {
    if (!_recording || _recStart == null) return;
    final offset = DateTime.now().difference(_recStart!).inMilliseconds;

    Player? player;
    if (_selectedTeam.players.isNotEmpty) {
      player = await _pickPlayer(_selectedTeam);
    }

    widget.match.events.add(MatchEvent(
      type: type,
      period: _period,
      matchSeconds: _elapsed,
      videoOffsetMs: offset,
      teamId: _selectedTeam.id,
      playerId: player?.id,
    ));
    await StorageService.instance.save();
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      duration: const Duration(seconds: 1),
      content: Text(
          '${type.emoji} ${type.label} · ${_selectedTeam.name}'
          '${player != null ? ' · ${player.name}' : ''}'),
    ));
  }

  Future<Player?> _pickPlayer(Team team) {
    return showModalBottomSheet<Player>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              title: Text('¿Quién? (${team.name})',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              trailing: TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Sin jugador')),
            ),
            for (final p in team.players)
              ActionChip(
                label: Text(
                    '${p.number != null ? '${p.number} ' : ''}${p.name}'),
                onPressed: () => Navigator.pop(ctx, p),
              ),
          ],
        ),
      ),
    );
  }

  String get _clock {
    final m = (_elapsed ~/ 60).toString().padLeft(2, '0');
    final s = (_elapsed % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _cam?.dispose();
    WakelockPlus.disable();
    WidgetsBinding.instance.removeObserver(this);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  // ---------- UI ----------

  @override
  Widget build(BuildContext context) {
    final match = widget.match;
    final overTime = _elapsed >= match.periodMinutes * 60;

    return PopScope(
      canPop: !_recording,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            // Vista de la cámara
            Positioned.fill(
              child: _camError != null
                  ? Center(
                      child: Text(_camError!,
                          style: const TextStyle(color: Colors.red)))
                  : _cam == null
                      ? const Center(child: CircularProgressIndicator())
                      : CameraPreview(_cam!),
            ),

            // Barra superior: marcador, cronómetro, espacio
            Positioned(
              top: 8,
              left: 8,
              right: 8,
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: _recording ? null : () => Navigator.pop(context),
                  ),
                  _scoreBox(match),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: _recording
                          ? (overTime ? Colors.orange : Colors.red)
                          : Colors.black54,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${_period == 1 ? '1T' : '2T'}  $_clock',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          fontFeatures: [FontFeature.tabularFigures()]),
                    ),
                  ),
                  const Spacer(),
                  if (_freeMb != null)
                    Text('${(_freeMb! / 1024).toStringAsFixed(1)} GB libres',
                        style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),

            // Selector de equipo (izquierda)
            Positioned(
              left: 12,
              top: 70,
              bottom: 90,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _teamChip(match.homeTeam),
                  const SizedBox(height: 10),
                  _teamChip(match.awayTeam),
                ],
              ),
            ),

            // Botones de eventos (derecha)
            Positioned(
              right: 12,
              top: 70,
              bottom: 90,
              child: Center(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      for (final t in EventType.values)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: EventButton(
                            type: t,
                            enabled: _recording,
                            onPressed: () => _addEvent(t),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),

            // Botón principal (abajo)
            Positioned(
              bottom: 16,
              left: 0,
              right: 0,
              child: Center(child: _mainButton()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _scoreBox(FootballMatch m) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
            color: Colors.black54, borderRadius: BorderRadius.circular(8)),
        child: Text(
          '${m.homeTeam.name} ${m.goalsFor(m.homeTeam)} - '
          '${m.goalsFor(m.awayTeam)} ${m.awayTeam.name}',
          style: const TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
      );

  Widget _teamChip(Team t) {
    final sel = _selectedTeam.id == t.id;
    return ChoiceChip(
      label: Text(t.name, style: const TextStyle(fontSize: 16)),
      selected: sel,
      onSelected: (_) => setState(() => _selectedTeam = t),
    );
  }

  Widget _mainButton() {
    if (_finished) {
      return FilledButton.icon(
        onPressed: () => Navigator.pop(context),
        icon: const Icon(Icons.check),
        label: const Text('Partido guardado · Volver',
            style: TextStyle(fontSize: 18)),
      );
    }
    if (_recording) {
      return FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: Colors.red),
        onPressed: _stopPeriod,
        icon: const Icon(Icons.stop),
        label: Text(_period == 1 ? 'Fin 1er tiempo' : 'Fin del partido',
            style: const TextStyle(fontSize: 18)),
      );
    }
    return FilledButton.icon(
      onPressed: _cam == null ? null : _startPeriod,
      icon: const Icon(Icons.fiber_manual_record),
      label: Text(_period == 1 ? 'Iniciar 1er tiempo' : 'Iniciar 2do tiempo',
          style: const TextStyle(fontSize: 18)),
    );
  }
}
