import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../models/models.dart';
import '../services/storage_service.dart';

/// Detalle del partido: reproductor de video + línea de tiempo de eventos.
/// Al tocar un evento el video salta 10 segundos antes del momento marcado.
class MatchDetailScreen extends StatefulWidget {
  const MatchDetailScreen({super.key, required this.match});
  final FootballMatch match;

  @override
  State<MatchDetailScreen> createState() => _MatchDetailScreenState();
}

class _MatchDetailScreenState extends State<MatchDetailScreen> {
  VideoPlayerController? _player;
  int _currentPeriod = 0;

  /// Segundos que se retrocede antes del evento para ver la jugada completa.
  static const _preRollSeconds = 10;

  @override
  void initState() {
    super.initState();
    final first = widget.match.videoPaths.keys.isEmpty
        ? null
        : (widget.match.videoPaths.keys.toList()..sort()).first;
    if (first != null) _loadPeriod(first);
  }

  Future<void> _loadPeriod(int period) async {
    final path = widget.match.videoPaths[period];
    if (path == null || !File(path).existsSync()) return;
    await _player?.dispose();
    final p = VideoPlayerController.file(File(path));
    await p.initialize();
    if (!mounted) return;
    setState(() {
      _player = p;
      _currentPeriod = period;
    });
  }

  Future<void> _jumpTo(MatchEvent e) async {
    if (_currentPeriod != e.period) await _loadPeriod(e.period);
    final p = _player;
    if (p == null) return;
    var ms = e.videoOffsetMs - _preRollSeconds * 1000;
    if (ms < 0) ms = 0;
    await p.seekTo(Duration(milliseconds: ms));
    await p.play();
    setState(() {});
  }

  Future<void> _deleteEvent(MatchEvent e) async {
    widget.match.events.removeWhere((x) => x.id == e.id);
    await StorageService.instance.save();
    setState(() {});
  }

  @override
  void dispose() {
    _player?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.match;
    final events = [...m.events]
      ..sort((a, b) => a.period != b.period
          ? a.period.compareTo(b.period)
          : a.matchSeconds.compareTo(b.matchSeconds));
    final p = _player;

    return Scaffold(
      appBar: AppBar(
        title: Text(
            '${m.homeTeam.name} ${m.goalsFor(m.homeTeam)} - ${m.goalsFor(m.awayTeam)} ${m.awayTeam.name}'),
      ),
      body: Column(
        children: [
          // ----- Reproductor -----
          if (p != null && p.value.isInitialized)
            AspectRatio(
              aspectRatio: p.value.aspectRatio,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  VideoPlayer(p),
                  VideoProgressIndicator(p, allowScrubbing: true),
                  Center(
                    child: IconButton(
                      iconSize: 64,
                      color: Colors.white70,
                      icon: Icon(p.value.isPlaying
                          ? Icons.pause_circle
                          : Icons.play_circle),
                      onPressed: () {
                        p.value.isPlaying ? p.pause() : p.play();
                        setState(() {});
                      },
                    ),
                  ),
                ],
              ),
            )
          else
            const AspectRatio(
              aspectRatio: 16 / 9,
              child: ColoredBox(
                color: Colors.black,
                child: Center(child: Text('Sin video para este partido')),
              ),
            ),

          // ----- Selector de tiempo -----
          if (m.videoPaths.length > 1)
            Padding(
              padding: const EdgeInsets.all(8),
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 1, label: Text('1er tiempo')),
                  ButtonSegment(value: 2, label: Text('2do tiempo')),
                ],
                selected: {_currentPeriod},
                onSelectionChanged: (s) => _loadPeriod(s.first),
              ),
            ),

          // ----- Línea de tiempo -----
          Expanded(
            child: events.isEmpty
                ? const Center(child: Text('No se marcaron eventos'))
                : ListView.separated(
                    itemCount: events.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final e = events[i];
                      final team = m.teamById(e.teamId);
                      final player = m.playerById(e.playerId);
                      return ListTile(
                        leading: Text(e.type.emoji,
                            style: const TextStyle(fontSize: 26)),
                        title: Text(
                            '${e.minuteLabel(m.periodMinutes)}  ${e.type.label} · ${team.name}'),
                        subtitle: player != null
                            ? Text(
                                '${player.number != null ? '${player.number} ' : ''}${player.name}')
                            : null,
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline, size: 20),
                          onPressed: () => _deleteEvent(e),
                        ),
                        onTap: m.videoPaths.containsKey(e.period)
                            ? () => _jumpTo(e)
                            : null,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
